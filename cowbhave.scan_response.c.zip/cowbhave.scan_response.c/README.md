# CowBhave firmware for Ruuvitag

Ruuvitag firmware focused on logging accelerometer data for behavioral monitoring. 

Significantly modified from: https://github.com/ruuvi/ruuvi.firmware.c . 